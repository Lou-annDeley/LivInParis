DELETE FROM Livraison WHERE etat_livraison = "En cours";

SELECT nom FROM Ingrédients WHERE id_Ingrédient = 1;

SELECT commentaire FROM Avis WHERE id_avis = 1; 

SELECT * FROM Client; 

SELECT COUNT(*) FROM Cuisinier; 

/*SET SQL_SAFE_UPDATES = 0;*/